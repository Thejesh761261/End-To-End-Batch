package com.candidjava.spring.service;

import java.util.List;

import com.candidjava.spring.bean.Emp;

public interface EmpService {
	public void createUser(Emp user);
	public List<Emp> getUser();
	public Emp findById(int id);
	public void update(Emp user);
	public void deleteUserById(int id);
	public void updatePartially(Emp user, int id);
}

