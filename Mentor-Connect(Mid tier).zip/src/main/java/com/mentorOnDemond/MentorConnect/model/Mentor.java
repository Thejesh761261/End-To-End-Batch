package com.mentorOnDemond.MentorConnect.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="mentor")
public class Mentor {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "mentorid")
	private int mentorid;
	
	@Column(name = "username")
	private String username;
	
	@Column(name = "linkedin_url")
	private String linkedin_url;
	
	@Column(name = "regdate")
	private Date regdate;
	
	@Column(name = "code")
	private String code;
	
	@Column(name = "experience")
	private int experience;
	
	@Column(name = "active")
	private String active;
	
	public Mentor()
	{
		
	}
	
	public Mentor(long id, int mentorid, String username, String linkedin_url, Date regdate, String code,
			int experience, String active) {
		super();
		this.id = id;
		this.mentorid = mentorid;
		this.username = username;
		this.linkedin_url = linkedin_url;
		this.regdate = regdate;
		this.code = code;
		this.experience = experience;
		this.active = active;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getMentorid() {
		return mentorid;
	}

	public void setMentorid(int mentorid) {
		this.mentorid = mentorid;
	}

	public String getLinkedin_url() {
		return linkedin_url;
	}

	public void setLinkedin_url(String linkedin_url) {
		this.linkedin_url = linkedin_url;
	}

	public Date getRegdate() {
		return regdate;
	}

	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "Mentor [id=" + id + ", mentorid=" + mentorid + ", username=" + username + ", linkedin_url="
				+ linkedin_url + ", regdate=" + regdate + ", code=" + code + ", experience=" + experience + ", active="
				+ active + "]";
	}

	
}
