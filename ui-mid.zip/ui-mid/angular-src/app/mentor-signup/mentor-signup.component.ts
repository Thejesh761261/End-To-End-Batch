import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.css']
})
export class MentorSignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
