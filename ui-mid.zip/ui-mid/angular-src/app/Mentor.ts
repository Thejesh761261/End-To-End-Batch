export class Mentor{
    id:number;
    mentorId:number;
    username:string;
    linkdin_url:string;
    regDate:Date;
    code:string;
    experience:number;
    active:string;

}