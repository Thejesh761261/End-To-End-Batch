import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mylearnings',
  templateUrl: './mylearnings.component.html',
  styleUrls: ['./mylearnings.component.css']
})
export class MylearningsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
