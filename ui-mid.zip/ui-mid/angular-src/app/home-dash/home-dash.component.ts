import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-dash',
  templateUrl: './home-dash.component.html',
  styleUrls: ['./home-dash.component.css']
})
export class HomeDashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
