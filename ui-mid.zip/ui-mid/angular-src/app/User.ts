export class User{
    id:number;
    userid:number;
    username:string;
    password:string;
    firstname:string;
    lastname:string;
    regDate:Date;
    code:string;
    active:string;
}