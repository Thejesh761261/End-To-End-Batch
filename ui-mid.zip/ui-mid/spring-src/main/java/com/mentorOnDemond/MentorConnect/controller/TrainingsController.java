package com.mentorOnDemond.MentorConnect.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mentorOnDemond.MentorConnect.model.Trainings;
import com.mentorOnDemond.MentorConnect.repository.TrainingsRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")

public class TrainingsController {
	
	@Autowired
	TrainingsRepository repository;

	@GetMapping("/trainings")
	public List<Trainings> getAllTrainings() {
		System.out.println("Get all Trainings...");

		List<Trainings> trainings = new ArrayList<>();
		repository.findAll().forEach(trainings::add);

		return trainings;
	}
	
	
	
	@GetMapping(value = "getTrainings/{id}")
	public List<Trainings> findById(@PathVariable long id) {

		List<Trainings> trainings = repository.findById(id);
		return trainings;
	}
	
	@GetMapping(value = "getTrainingsUnderProgress/{status}")
	public List<Trainings> findByStatus(@PathVariable String status) {

		List<Trainings> trainings = repository.findByStatus(status);
		return trainings;
	}
	
	@PostMapping(value = "/trainings/create")
	public Trainings postTrainings(@RequestBody Trainings training) {

		Trainings _customer = repository.save(new Trainings(training.getId(), training.getUid(), training.getMid(),training.getSid(),
				training.getStatus(),training.getProgress(),training.getRating(),training.getStart_time(),training.getEnd_time(),training.getStart_date(),
				training.getEnd_date(),training.getAmount_received()));
		return _customer;
	}
	
	@DeleteMapping("/trainings/delete/{id}")
	public ResponseEntity<String> deleteTrainings(@PathVariable("id") long id) {
		System.out.println("Delete Trainings with ID = " + id + "...");

		repository.deleteById(id);

		return new ResponseEntity<>("Training has been deleted!", HttpStatus.OK);
	}
	

	
	
	
	

}
