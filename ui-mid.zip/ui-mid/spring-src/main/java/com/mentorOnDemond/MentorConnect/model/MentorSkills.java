package com.mentorOnDemond.MentorConnect.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="mentor_skills")
public class MentorSkills {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "mid")
	private int mid;
	
	@Column(name = "sid")
	private int sid;
	
	@Column(name = "self_rating")
	private int self_rating;
	
	@Column(name = "experience")
	private int experience;
	
	@Column(name = "trainings_delivered")
	private int trainings_delivered;
	
	@Column(name = "facilities")
	private String facilities;
	
	public MentorSkills()
	{
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public int getSelf_rating() {
		return self_rating;
	}

	public void setSelf_rating(int self_rating) {
		this.self_rating = self_rating;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public int getTrainings_delivered() {
		return trainings_delivered;
	}

	public void setTrainings_delivered(int trainings_delivered) {
		this.trainings_delivered = trainings_delivered;
	}

	public String getFacilities() {
		return facilities;
	}

	public void setFacilities(String facilities) {
		this.facilities = facilities;
	}

	@Override
	public String toString() {
		return "MentorSkills [id=" + id + ", mid=" + mid + ", sid=" + sid + ", self_rating=" + self_rating
				+ ", experience=" + experience + ", trainings_delivered=" + trainings_delivered + ", facilities="
				+ facilities + "]";
	}

	public MentorSkills(long id, int mid, int sid, int self_rating, int experience, int trainings_delivered,
			String facilities) {
		super();
		this.id = id;
		this.mid = mid;
		this.sid = sid;
		this.self_rating = self_rating;
		this.experience = experience;
		this.trainings_delivered = trainings_delivered;
		this.facilities = facilities;
	}
	
	

}
