package com.mentorOnDemond.MentorConnect.repository;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.mentorOnDemond.MentorConnect.model.Mentor;

public interface MentorRepository extends CrudRepository<Mentor, Long> {

	List<Mentor> findById(long id);
	List<Mentor> findByMentorid(int mid);
}
