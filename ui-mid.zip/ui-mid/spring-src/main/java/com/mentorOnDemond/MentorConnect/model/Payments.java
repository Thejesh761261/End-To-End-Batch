package com.mentorOnDemond.MentorConnect.model;


import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin")
public class Payments {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "mid")
	private int mid;
	
	@Column(name = "sid")
	private int sid;
	
	@Column(name = "txn_type")
	private String txn_type;
	
	@Column(name = "amount")
	private int amount;
	
	@Column(name = "time")
	private Date time;
	
	public Payments() {
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getTxn_type() {
		return txn_type;
	}

	public void setTxn_type(String txn_type) {
		this.txn_type = txn_type;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "Payments [id=" + id + ", mid=" + mid + ", sid=" + sid + ", txn_type=" + txn_type + ", amount=" + amount
				+ ", time=" + time + "]";
	}

	public Payments(long id, int mid, int sid, String txn_type, int amount, Date time) {
		super();
		this.id = id;
		this.mid = mid;
		this.sid = sid;
		this.txn_type = txn_type;
		this.amount = amount;
		this.time = time;
	}
	
	
	
	

}
