package com.mentorOnDemond.MentorConnect.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.mentorOnDemond.MentorConnect.model.Trainings;

public interface TrainingsRepository extends CrudRepository<Trainings, Long> {

	List<Trainings> findById(long id);
	List<Trainings> findByStatus(String status);
}
