package com.mentorOnDemond.MentorConnect.repository;

import java.util.List;


import org.springframework.data.repository.CrudRepository;

import com.mentorOnDemond.MentorConnect.model.Skills;

public interface SkillsRepository extends CrudRepository<Skills, Long>{

	List<Skills> findById(long id);
	List<Skills> findByName(String name);
}
