package com.example.demo.service;

import com.example.demo.client.GetNotesServiceClient;
import com.example.demo.client.model.GetNotesClientRequest;
import com.example.demo.client.model.NotesRoot;
import com.example.demo.resource.model.GetNotesRequest;
import com.example.demo.resource.model.NoteResponse;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GetNotesServiceImpl implements GetNotesService {

    @Autowired
    private GetNotesServiceClient getNotesServiceClient;

    @Override
    public List<NoteResponse> getNotes(GetNotesRequest getNotesRequest) {

        //Build Client Request
        GetNotesClientRequest getNotesClientRequest = new GetNotesClientRequest();
        getNotesClientRequest.setReservationNumber(getNotesRequest.getReservationNumber());
        if(getNotesRequest.getNoteType().equals("260")){
            getNotesClientRequest.setAssociateId("1");
        } else {
            getNotesClientRequest.setAssociateId("2");
        }

        //Client Api
        NotesRoot notesRoot = getNotesServiceClient.getNotes(getNotesClientRequest);

        List<NoteResponse> noteResponses = new ArrayList<>();
        //Business Logic
        notesRoot.getNotesClientResponse().getNoteClientResponses().stream().filter(noteClientResponse ->
                noteClientResponse.getStatus().equals(getNotesRequest.getLineNumber())).forEach(noteClientResponse -> {
                    NoteResponse noteResponse = new NoteResponse();
                    BeanUtils.copyProperties(noteClientResponse, noteResponse);
                    noteResponses.add(noteResponse);
        });

        return noteResponses;

    }
}
