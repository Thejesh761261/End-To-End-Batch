package com.example.demo.service;

import com.example.demo.resource.model.GetNotesRequest;
import com.example.demo.resource.model.NoteResponse;
import java.util.List;

public interface GetNotesService {

    List<NoteResponse> getNotes(GetNotesRequest getNotesRequest);
}
