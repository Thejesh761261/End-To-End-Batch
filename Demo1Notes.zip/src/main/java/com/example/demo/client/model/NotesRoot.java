package com.example.demo.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotesRoot implements Serializable {

    private static final long serialVersionUID = -5941159620921756009L;

    @JsonProperty("Notes")
    private NotesClientResponse notesClientResponse;

    public NotesClientResponse getNotesClientResponse() {
        return notesClientResponse;
    }

    public void setNotesClientResponse(NotesClientResponse notesClientResponse) {
        this.notesClientResponse = notesClientResponse;
    }
}
