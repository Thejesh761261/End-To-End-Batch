package com.example.demo.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import java.io.Serializable;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotesClientResponse implements Serializable {

    private static final long serialVersionUID = -7009288844351768601L;

    @JsonProperty("Note")
    private List<NoteClientResponse> noteClientResponses;

    public List<NoteClientResponse> getNoteClientResponses() {
        return noteClientResponses;
    }

    public void setNoteClientResponses(List<NoteClientResponse> noteClientResponses) {
        this.noteClientResponses = noteClientResponses;
    }
}
