package com.example.demo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SpringBootApplication
@EnableHystrix
public class DemoApplication<str> {


	public DemoApplication() throws JsonProcessingException {
	}

	public static void main(String[] args) throws JsonProcessingException {

		SpringApplication.run(DemoApplication.class, args);

	}





}
