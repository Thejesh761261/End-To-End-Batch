package com.example.demo.resource;

import com.example.demo.resource.model.GetNotesRequest;
import com.example.demo.resource.model.NoteResponse;
import com.example.demo.service.GetNotesService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestHystrix {

    @Autowired
    private GetNotesService getNotesService;

    @GetMapping("/reservation-number/{reservationNumber}/notes")
    public List<NoteResponse> getNotesResponse(@PathVariable("reservationNumber")final String reservationNumber){
        //Build Request
        GetNotesRequest getNotesRequest = new GetNotesRequest();
        getNotesRequest.setLineNumber("1");
        getNotesRequest.setNoteType("260");
        getNotesRequest.setReservationNumber(reservationNumber);

        // Service Call
        List<NoteResponse> notesRoot = getNotesService.getNotes(getNotesRequest);

        return notesRoot;
    }

}
