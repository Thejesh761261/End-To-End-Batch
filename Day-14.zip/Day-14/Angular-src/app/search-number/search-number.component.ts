import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-search-number',
  templateUrl: './search-number.component.html',
  styleUrls: ['./search-number.component.css']
})
export class SearchNumberComponent implements OnInit {
  number: string;
  customers: Customer[];

  constructor(private dataService: CustomerService) { }

  ngOnInit() {
    this.number = "";
  }

  private searchCustomers() {
    this.dataService.getCustomersByNumber(this.number)
      .subscribe(customers => this.customers = customers);
  }

  onSubmit() {
    this.searchCustomers();
  }
}
