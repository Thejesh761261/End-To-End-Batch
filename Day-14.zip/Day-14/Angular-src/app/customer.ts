export class Customer {
    id: number;
    name: string;
    age: number;
    active: boolean;
    number: string;
}
