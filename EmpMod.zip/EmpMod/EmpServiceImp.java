package com.candidjava.spring.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.candidjava.spring.bean.Emp;

@Service
public class EmpServiceImp implements EmpService {

	private static List<Emp> users;

	static {
		users = dummyUsers();
	}

	public List<Emp> getUser() {
		// TODO Auto-generated method stub
		return users;
	}

	public Emp findById(int id) {
		// TODO Auto-generated method stub
		for (Emp user : users) {
			if (user.getId() == id) {
				return user;
			}
		}
		return null;
	}

	public void createUser(Emp user) {
		// TODO Auto-generated method stub
		users.add(user);
	}

	public void deleteUserById(int id) {
		// TODO Auto-generated method stub
		Iterator<Emp> it = users.iterator();
		while (it.hasNext()) {
			Emp user = (Emp) it.next();
			if (user.getId() == id) {
				it.remove();
			}
		}
	}

	public void updatePartially(Emp currentUser, int id) {
		for (Emp user : users) {
			if (user.getId() == id) {
				if (currentUser.getDepartment() != null) {
					user.setId(id);
					user.setDepartment(currentUser.getDepartment());
				}
				user.setName(user.getName());
				update(user);
			}
		}

	}

	public void update(Emp user) {
		// TODO Auto-generated method stub
		int index = users.indexOf(user);
		users.set(index, user);
	}

	private static List<Emp> dummyUsers() {
		// TODO Auto-generated method stub
		List<Emp> users = new ArrayList<Emp>();
		users.add(new Emp(161261, "DEPLOYMENT" ,"Thejesh"));
		users.add(new Emp(165432,"DEVELOPMENT", "Ben" ));
		users.add(new Emp(165786,"TESTING", "Andrew" ));
		users.add(new Emp(156543,"DESIGNING", "Samuael" ));
		return users;
	}
	
	public int getMaxSal()
	{
		int sd=0;
		for(int i=0;i<users.size();i++)
		{
			if(sd<=users.get(i).getId())
			{
				sd=users.get(i).getId();
				
			}
		}
		
		return sd;
	}

	
	
}

