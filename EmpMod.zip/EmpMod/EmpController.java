package com.candidjava.spring.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;
import com.candidjava.spring.bean.Emp;
import com.candidjava.spring.service.EmpService;

@RestController
@RequestMapping(value={"/employee"})
public class EmpController {

	@Autowired
	EmpService EmpService;
	

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Emp> getEmpById(@PathVariable("id") int id) {
        System.out.println("Fetching Emp with id " + id);
        Emp Emp = EmpService.findById(id);
        if (Emp == null) {
            return new ResponseEntity<Emp>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Emp>(Emp, HttpStatus.OK);
    }
    
	 @PostMapping(value="/create",headers="Accept=application/json")
	 public ResponseEntity<Void> createEmp(@RequestBody Emp Emp, UriComponentsBuilder ucBuilder){
	     System.out.println("Creating Emp "+Emp.getName());
	     EmpService.createUser(Emp);
	     HttpHeaders headers = new HttpHeaders();
	     headers.setLocation(ucBuilder.path("/emplloyee/{id}").buildAndExpand(Emp.getId()).toUri());
	     return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	 }

	 @GetMapping(value="/get", headers="Accept=application/json")
	 public List<Emp> getAllEmp() {	 
	  List<Emp> tasks=EmpService.getUser();
	  return tasks;
	
	 }
	 
	 @GetMapping(value="/max", headers="Accept=application/json")
	 public int getMaxSal() {	 
	 int tasks=EmpService.getMaxSal();
	 return tasks;
	
	 }

	@PutMapping(value="/update", headers="Accept=application/json")
	public ResponseEntity<String> updateEmp(@RequestBody Emp currentEmp)
	{
	Emp Emp = EmpService.findById(currentEmp.getId());
	if (Emp==null) {
		return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
	}
	Emp.setId(currentEmp.getId());
	Emp.setName(currentEmp.getName());
	Emp.setDepartment(currentEmp.getDepartment());
	EmpService.update(Emp);
	return new ResponseEntity<String>(HttpStatus.OK);
	}
	
	@DeleteMapping(value="/{id}", headers ="Accept=application/json")
	public ResponseEntity<Emp> deleteEmp(@PathVariable("id") int id){
		Emp Emp = EmpService.findById(id);
		if (Emp == null) {
			return new ResponseEntity<Emp>(HttpStatus.NOT_FOUND);
		}
		EmpService.deleteUserById(id);
		return new ResponseEntity<Emp>(HttpStatus.NO_CONTENT);
	}
	
	@PatchMapping(value="/{id}", headers="Accept=application/json")
	public ResponseEntity<Emp> updateEmpPartial(@PathVariable("id") int id, @RequestBody Emp currentEmp){
		Emp Emp = EmpService.findById(id);
		if(Emp ==null){
			return new ResponseEntity<Emp>(HttpStatus.NOT_FOUND);
		}
		
		EmpService.updatePartially(currentEmp, id);
		return new ResponseEntity<Emp>(Emp, HttpStatus.OK);
	}
	
	@PostMapping(value="/createMul",headers="Accept=application/json")
	 public ResponseEntity<Void> createMulEmp(@RequestBody List<Emp> emp, UriComponentsBuilder ucBuilder){
	     System.out.println("Creating Employees "+emp);
	     for(Emp emp1:emp)
	     {
	    	 EmpService.createUser(emp1);
	     }
	     
	     //HttpHeaders headers = new HttpHeaders();
	     //headers.setLocation(ucBuilder.path("/emplloyee/{id}").buildAndExpand(Emp.getId()).toUri());
	     return new ResponseEntity<Void>(HttpStatus.CREATED);
	 }

}
